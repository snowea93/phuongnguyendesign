
					<div class="nav-pages">
						<a href="#" title="Previous" class="link-prev">
							<div>
								<span>Previous</span>
							</div>
						</a><!-- // .link-prev -->

						<a href="#" title="Next" class="link-next">
							<div>
								<span>Next</span>
							</div>
						</a><!-- // .link-next -->
						
						<div class="clear"></div>
					</div><!-- // .nav-pages -->